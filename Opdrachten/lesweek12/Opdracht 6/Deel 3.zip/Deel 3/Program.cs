﻿using System;

namespace Deel_3
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Geef uw figuur in Cikel/Vierkant/Rechthoek");
            string type = Console.ReadLine();
            Vorm obj = createVorm.getobject(type);
            Console.WriteLine(obj);
            Console.ReadLine();
            

        }
    }
    public class createVorm{
        public static Vorm getobject(string typeofobj){
            Vorm obj = null;
            if(typeofobj.ToLower()=="cirkel"){
                obj = new Cirkel();
            }else if (typeofobj.ToLower()=="vierkant"){
                obj = new Vierkant();
            }else{   
                obj = new Rechthoek();
            }
            return obj.getShape();
        }
    }
    public interface Vorm{
        string getShape();
    }
    class Cirkel: Vorm{
        public string getShape(){
            return "Dit is een cirkel";
        }
    }
    class Vierkant: Vorm{
        public string getShape(){
            return "Dit is een vierkant";
        }
    }
    class Rechthoek: Vorm{
        public string getShape(){
            return "Dit is een rechthoek";
        }
    }
}
