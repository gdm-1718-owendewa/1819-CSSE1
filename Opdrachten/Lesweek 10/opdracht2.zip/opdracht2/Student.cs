namespace opdracht2{
     public class Student{
    }
}
