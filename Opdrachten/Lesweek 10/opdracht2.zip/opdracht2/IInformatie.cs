namespace opdracht2{
    public interface IInformatie{
        string ToString();
    }
}