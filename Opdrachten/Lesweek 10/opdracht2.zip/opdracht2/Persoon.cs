namespace opdracht2{
     public class Persoon{
    }
}
